#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <netinet/in.h>
#include <pthread.h>
#include <unistd.h>

#define _GNU_SOURCE 
#include <string.h>

#define BUFFER_SIZE 256
#define MAX_NUM_LISTENER_ALLOWED 10

/*
 * Identifies if the specified message is well-formed or not.
 *
 * msg - the message to be tested
 *
 * returns a value greater than 0 if the message is well formed and a value less than zero if it is not
 */
int wellFormed(char* msg)
{	
	int length = strlen(msg);

	if (strcasecmp(msg, "<loadavg/>") == 0) {
		if (length != 10) {
			return -1;
		}
		return 1;
	}
	if (strncasecmp(msg, "<echo>", 6) == 0) {
		char* endStr = strstr(msg, "</echo>");
		if (endStr == NULL)
			return -1;
		if (endStr[7] != '\0')
			return -1;
		return 1;
	}

	return -1;
}

/*
 * Determines the load average and writes it as an XML formatted string into the specified string location.
 *
 * resp - memory for a text string to store the XML formatted string specifying load average information
 */
void getLoadAvgResp(char* resp)
{
	double resultRuntime[3];
	
	bzero(resp, BUFFER_SIZE);
	
	if (getloadavg(resultRuntime, 3) < 0) {
		strcpy(resp, "<error>unable to obtain load average</error>");
		return;
	}
	
	sprintf(resp, "<replyLoadAvg>%f:%f:%f</replyLoadAvg>", resultRuntime[0], resultRuntime[1], resultRuntime[2]);
}

/*
 * Generates a response to a request message in accordance with the given protocol in the project documentation.
 * The request message is assumed to be in a correct format.
 * 
 * msg - the message that specifies the request from a client
 * resp - memory for a text string to store the response to a request
 */
void getResponse(char* msg, char* resp)
{
	bzero(resp, BUFFER_SIZE);

	if (strcasecmp(msg, "<loadavg/>") == 0) {
		getLoadAvgResp(resp);
		return;
	}

	if (strncasecmp(msg, "<echo>", 6) == 0) {
		int payLoadLength = strlen(msg)-13;
		strcpy(resp, "<reply>");
		strncpy(&resp[7], &msg[6], payLoadLength);
		strcpy(&resp[7+payLoadLength], "</reply>");
		return;
	}
}

/*
 * Writes an error message into the specified character array.
 *
 * msg - memory for a text string to store the error message 
 */
void createError(char* msg)
{
	bzero(msg, BUFFER_SIZE);
	strcpy(msg, "<error>unknown format</error>");
}

/* 
 * Prints the host name of the machine to the screen.
 */
void printHostInfo()
{
	// getting host name and use dynamic port binding
	char hostname[128];
	gethostname(hostname, 128);
	printf ("Hostname: %s\n", hostname);
}

/* 
 * Creates a socket and binds it dynamicaly. Port information of the bound socket is returned.
 */
int createSocket()
{
	struct sockaddr_in servaddr;
	int                listensockfd;

	// creating a streaming server socket
	listensockfd = socket (PF_INET, SOCK_STREAM, 0);
	if (listensockfd < 0) {
		return -1;
	}
	
	// build local address and set port to unknown
	memset ((void *) &servaddr, 0, (size_t)sizeof(servaddr));
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	servaddr.sin_port = htons(0);

	// bind dynamically
	bind (listensockfd, (struct sockaddr *) &servaddr, (socklen_t)sizeof(servaddr));

	// retrieve port information
	struct sockaddr_in boundAddr;
	socklen_t          sizeAddr = sizeof(boundAddr);
	getsockname(listensockfd, (struct sockaddr *) &boundAddr, &sizeAddr);
	printf ("Port: %d\n", ntohs(boundAddr.sin_port));

	return listensockfd;
}

/*
 * Implements the request handler executed within a thread.
 */
void* reqHandler(void *value)
{
	int  sockfd = (intptr_t)value;
	char msg[BUFFER_SIZE];
	char resp[BUFFER_SIZE];

	printf("Received a request... ");
	recv(sockfd, (void*)msg, BUFFER_SIZE, MSG_WAITALL);
	printf ("%s\n", msg);

	if (wellFormed(msg) < 0) {
		createError(resp);
	}
	else {
		getResponse(msg, resp);	
	}
	write(sockfd, resp, BUFFER_SIZE);
	printf("Sent response %s\n", resp);

	close (sockfd);
	pthread_exit(0);
}

/*
 * The main program that starts up the server.
 * No parameters are processed.
 */ 
int main(int argc, char** argv) 
{	
	int        listensockfd, connsockfd;
	pthread_t  tid;  

	// provide host name information to the screen
	printHostInfo();

	// creating a streaming server socket
	listensockfd = createSocket();
	if (listensockfd < 0) {
		perror ("cannot create socket");
		exit (1);
	}
	
	// list on server socket
	listen (listensockfd, MAX_NUM_LISTENER_ALLOWED);
	
	for (;;) {
		printf("Waiting for connection..."); fflush(stdout);
		connsockfd = accept(listensockfd, NULL, NULL);
		printf ("...connected.\n"); fflush(stdout);

		pthread_create(&tid, NULL, reqHandler, (void*)(intptr_t)connsockfd);
		pthread_detach(tid);
	}
	
}

