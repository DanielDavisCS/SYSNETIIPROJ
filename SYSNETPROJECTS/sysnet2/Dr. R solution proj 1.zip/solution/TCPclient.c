#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <netinet/in.h>
#include <string.h>
#include <unistd.h>

#define BUFFER_SIZE 256

int createSocket(char* serverName, int port, struct sockaddr_in * dest)
{
	int                sockfd;
	struct hostent     *hostptr;

	// creating a streaming client socket
	sockfd = socket (AF_INET, SOCK_STREAM, 0);
	if (sockfd < 0) {
		perror ("cannot create socket");
		return -1;
	}
	
	// getting destination host name and port information
	if ((hostptr = gethostbyname (serverName)) == NULL) {
		perror ("invalid host name");
		return -1;	
	}

	// build destination address	
	memset ((void *) dest, 0, (size_t)sizeof(struct sockaddr_in));
	dest->sin_family = (short)(AF_INET);
	memcpy ((void *) &dest->sin_addr, (void *) hostptr->h_addr, hostptr->h_length);
	dest->sin_port = htons (port);

	// connect to server
	printf ("Connecting to server %s ....", serverName);
	fflush(stdout);
	if (connect(sockfd, 
                    (struct sockaddr*)dest, 
                    sizeof(struct sockaddr_in))) {
		perror ("cannot connect to server");
		return -1;	
	}
	printf ("done.\n");

	return sockfd;
}

int sendRequest(int sock, char * request, struct sockaddr_in * dest)
{
	char buffer[BUFFER_SIZE];

	// send request to server
	printf ("Sending to server ... %s\n", request);
	bzero (buffer, BUFFER_SIZE);
	strcpy (buffer, request);
	send (sock, buffer, BUFFER_SIZE, 0);
	return 0;
}

int receiveResponse(int sock, char * response) 
{
	char buffer[BUFFER_SIZE];

 	// read data from socket; read waits for data from socket
    bzero (buffer, BUFFER_SIZE);
	recv (sock, buffer, BUFFER_SIZE-1, 0);

	strcpy (response, buffer);

	return 0;
}

void printResponse(char * response)
{
	printf ("Server responded with");
	printf ("   %s\n", response);
}


