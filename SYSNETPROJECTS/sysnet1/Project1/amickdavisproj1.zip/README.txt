@mainpage System and Networks I Project 1
@last modified September 12, 2013

@author Cole Amick
@author Daniel Davis

@files required
parse.c
Makefile

@how to compile
make

@how to run
./shellparser

@description of program
Takes input from user and stores into buffer.
Then parses the buffer and initalizes the required parameters in data
structures. Before each iteration of user input the input buffer and data
structure is freed. 

@additional notes
We set a predefined size of 100 for the size of each token or name deliminted
by only spaces. 
There is a set limit of only 32 arguments that can be entered into input.
There are no spaces allowed between file redirection symbols (< or >) and the
name of the file. Acceptable file names include any non-white spaced
characters. 
The first name of the input cannot be a file redirection symbol or a
ampersand. 
Type only exit and then the program will terminate. 
